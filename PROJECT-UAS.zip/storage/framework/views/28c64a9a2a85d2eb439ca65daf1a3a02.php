<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Biodata</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
    <div class="p-5 bg-primary text-white text-center">
        <h1>ADMIN</h1>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('input_form.index')); ?>">SuruhLEO</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                
                </li>
                <?php if(auth()->guard()->check()): ?>
                
                    <li class="nav-item">
                        <form id="logoutForm" action="/logout" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="button" onclick="confirmLogout()" class="nav-link text-danger fw-bold border border-light rounded-3 p-2 m-1 bg-transparent" style="transition: background-color 0.3s ease, color 0.3s ease;">
                                Logout
                            </button>
                        </form>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#" data-bs-toggle="modal" data-bs-target="#loginModal">Login</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Alert Logout -->
<?php if(session('goodbye')): ?>
    <div class="alert alert-warning alert-dismissible fade show m-3" role="alert">
        <strong><?php echo e(session('goodbye')); ?></strong> <br> Anda telah berhasil keluar dari akun.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<main class="container my-4 text-black">
        <h1>Selamat datang, Admin <?php echo e(auth()->user()->name); ?></h1>
        <p>Akun email kamu <?php echo e(auth()->user()->email); ?></p>
    </main>

    <!-- Main Content -->
    <div class="container mt-4">
    <h2 class="mb-4">Daftar Job Yang Akan Diambil</h2>
    <div class="row g-3">
    <?php $__currentLoopData = $input_form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
            <div class="card-body">
    <p><strong>Nama:</strong> <?php echo e($form->name); ?></p>
    <p><strong>No Telp:</strong> <?php echo e($form->no_telp); ?></p>
    <p><strong>Prodi:</strong> <?php echo e($form->prodi); ?></p>
    <p><strong>Jenis Kelamin:</strong> <?php echo e($form->gender == 'male' ? 'Laki-Laki' : 'Perempuan'); ?></p>
    <p><strong>Deskripsi:</strong> <?php echo e($form->description); ?></p>
    <p><strong>Status:</strong> <?php echo e($form->status); ?></p>
    <a href="<?php echo e(route('input_form.edit', $form->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
    <form action="<?php echo e(route('input_form.update_status', $form->id)); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <button type="submit" class="btn btn-success btn-sm">Terima</button>
    </form>
    <form action="<?php echo e(route('input_form.mark_complete', $form->id)); ?>" method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button type="submit" class="btn btn-primary">Selesai</button>
        </form>
    <form action="<?php echo e(route('input_form.destroy', $form->id)); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
    </form>
</div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

<script>
function confirmLogout() {
    if (confirm("Apakah Anda yakin ingin keluar?")) {
        document.getElementById('logoutForm').submit();
    }
}

    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
</script>

</html>
<?php /**PATH C:\laragon\www\PROJECT-UAS\resources\views/input_form/index.blade.php ENDPATH**/ ?>