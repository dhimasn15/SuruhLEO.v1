<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-dark">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('input_form.index')); ?>">SuruhLEO</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('input_form.home')); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('input_form.home')); ?>">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('input_form.home')); ?>">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('input_form.home')); ?>">Service</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('input_form.create')); ?>">Input Job Suruh</a></li>
                </ul>
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search">
                    <button class="btn btn-primary" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class=" container my-5">
        <h1 class="mb-4 text-white">Konfirmasi</h1>
        <div class="card shadow-sm  bg-dark p-4">
            <p class="text-white"><strong>Nama:</strong> <?php echo e($name); ?></p>
            <p class="text-white"><strong>No Telepon:</strong> <?php echo e($no_telp); ?></p>
            <p class="text-white"><strong>Prodi:</strong> <?php echo e($prodi); ?></p>
            <p class="text-white"><strong>Gender:</strong> <?php echo e($gender); ?></p>
            <p class="text-white"><strong>Deskripsi Bantuan:</strong> <?php echo e($description); ?></p>
        </div>
        <a href="<?php echo e(route('input_form.home')); ?>" class="btn btn-secondary mt-3">Kembali ke daftar biodata</a>
        </div>
    </div>
    

    <!-- Footer -->
    <footer class="bg-dark text-white pt-4 pb-2">
        <div class="container">
            <div class="row">
                <!-- Kolom 1 -->
                <div class="col-md-4 mb-4">
                    <h5 class="text-warning fw-bold">SuruhLEO</h5>
                    <p>Deskripsi singkat tentang perusahaan atau tujuan websitemu. Tambahkan informasi singkat yang relevan.</p>
                </div>

                <!-- Kolom 2 -->
                <div class="col-md-2 mb-4">
                    <h6 class="text-uppercase fw-bold">Tautan</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white text-decoration-none">Beranda</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Tentang</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Layanan</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Kontak</a></li>
                    </ul>
                </div>

                <!-- Kolom 3 -->
                <div class="col-md-3 mb-4">
                    <h6 class="text-uppercase fw-bold">Ikuti Kami</h6>
                    <a href="#" class="btn btn-outline-light btn-sm me-2">Facebook</a>
                    <a href="#" class="btn btn-outline-light btn-sm me-2">Instagram</a>
                    <a href="#" class="btn btn-outline-light btn-sm me-2">Twitter</a>
                </div>

                <!-- Kolom 4 -->
                <div class="col-md-3 mb-4">
                    <h6 class="text-uppercase fw-bold">Kontak</h6>
                    <p><i class="fas fa-home me-2"></i> Alamat Perusahaan, Kota</p>
                    <p><i class="fas fa-envelope me-2"></i> info@example.com</p>
                    <p><i class="fas fa-phone me-2"></i> +62 123 4567 890</p>
                </div>
            </div>
        </div>

        <div class="text-center p-3 border-top">
            © 2024 SuruhLEO. All Rights Reserved.
        </div>
    </footer>

    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\PROJECT-UAS\resources\views/input_form/result.blade.php ENDPATH**/ ?>