<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
class SesiController extends Controller
{
    public function index()
    {
        return view('input_form/login');
    }

    public function login(Request $request)
{
    $request->validate([
        'email' => 'required',
        'password' => 'required'
    ], [
        'email.required' => 'Email wajib diisi',
        'password.required' => 'Password wajib diisi',
    ]);

    $infologin = [
        'email' => $request->email,
        'password' => $request->password,
    ];

    if (Auth::attempt($infologin)) {
        // Jika login berhasil
        $user = Auth::user();

        if ($user->role === 'admin') {
            return redirect()->route('input_form.index')->with('login_success', 'Selamat datang, Admin!');
        } else if ($user->role === 'user') {
            return redirect()->route('input_form.home')->with('login_success', 'Selamat datang, Anda berhasil login!');
        }

        // Default fallback (jika peran tidak dikenali)
        Auth::logout();
        return redirect()->route('login')->with('error', 'Peran tidak dikenali.');
    } else {
        // Jika login gagal
        return redirect()->back()->with('error', 'Email atau password salah');
    }
}


    public function logout()
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
    
        return redirect()->route('input_form.home')->with('goodbye', 'Selamat Tinggal! Semoga hari Anda menyenankan."kata Leo"');}


    public function showLoginForm()
    {
        return view('input_form/login'); // Sesuaikan dengan path view login kamu.
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'user', // Opsional jika ingin memastikan default role
        ]);

        return redirect()->route('input_form.home')->with('daftar', 'Pendaftaran berhasil! Silakan login.');
    }

}
